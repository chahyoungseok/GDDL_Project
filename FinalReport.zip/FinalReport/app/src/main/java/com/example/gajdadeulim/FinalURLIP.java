package com.example.gajdadeulim;

public class FinalURLIP {
    public final static String ip = "10.0.2.2";
    public final static String port = "8080";
}
