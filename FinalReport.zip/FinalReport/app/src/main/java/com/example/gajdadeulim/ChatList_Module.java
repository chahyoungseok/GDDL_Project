package com.example.gajdadeulim;

public class ChatList_Module {
    private String orderID;
    private String errandID;
    private int Num;

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getErrandID() {
        return errandID;
    }

    public void setErrandID(String errandID) {
        this.errandID = errandID;
    }

    public int getNum() {
        return Num;
    }

    public void setNum(int num) {
        Num = num;
    }
}
